#!/bin/sh
echo "Xiaomi Hacks enabled"

/mnt/sdcard/manu_test/disable_factory_mode.sh
#/mnt/sdcard/hacks/bin/busybox telnetd &
/mnt/sdcard/hacks/installer/install.sh &
