#!/bin/sh
echo "Xiaomi Hacks enabled"
rm -rf /tmp/factory_mode

#/mnt/sdcard/manu_test/configure_services.sh &

onvif_srvd --no_fork --pid_file /var/run/onvif_srvd.pid --ifs wlan0 --port 5000 --scope onvif://www.onvif.org/Profile/S --name RTSP --width 1920 --height 1080 --url rtsp://10.8.28.48:8554/mainstream --type H264 --manufacturer Xiaomi --model MJSXJ05CM --user admin --password !s3cr3t --ptz --move_left eval echo "pan forward 5" > /var/run/event --move_right eval echo "pan reverse 5" > /var/run/event --move_up eval echo "tilt forward 5" > /var/run/event --move_down eval echo "tilt reverse 5" > /var/run/event &

rm -f /var/run/rtsp_mainstream && mkfifo /var/run/rtsp_mainstream
rm -rf /var/run/rtsp_substream && mkfifo /var/run/rtsp_substream

framegrabber -f /var/run/rtsp_mainstream -c 0 &
rtspserver -c /mnt/data/config/rtsp.json -m /var/run/rtsp_mainstream &
