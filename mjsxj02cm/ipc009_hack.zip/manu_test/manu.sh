#!/bin/sh
echo "Xiaomi Hacks enabled"
rm -rf /tmp/factory_mode

/mnt/sdcard/manu_test/configure_services.sh &
